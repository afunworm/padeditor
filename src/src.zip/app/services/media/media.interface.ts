export interface MediaInterface {
	[name: string]: any;
}
